const FOCUS_TIME = 10; 
const BREAK_TIME = 2;   

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({ 
    isRunning: false, 
    mode: 'Focus', 
    timeLeft: FOCUS_TIME * 60 
  });
});

chrome.runtime.onMessage.addListener((message) => {
  if (message.action === "start") startTimer();
  if (message.action === "stop") stopTimer();
});

function startTimer() {
  chrome.storage.local.set({ isRunning: true });
  chrome.alarms.create("pomodoroAlarm", { periodInMinutes: 1 / 60 });
}

function stopTimer() {
  chrome.alarms.clear("pomodoroAlarm");
  chrome.storage.local.set({ isRunning: false, mode: 'Focus', timeLeft: FOCUS_TIME * 60 });
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "pomodoroAlarm") {
    chrome.storage.local.get(["timeLeft", "mode"], (data) => {
      let timeLeft = data.timeLeft - 1;
      let mode = data.mode;

      if (timeLeft <= 0) {
        // Send message to popup to play the loud beep
        chrome.runtime.sendMessage({ action: "play_sound" }).catch(() => {
            // If popup is closed, the notification will handle the system sound
            console.log("Popup closed, relying on system notification sound.");
        });

        if (mode === "Focus") {
          mode = "Break";
          timeLeft = BREAK_TIME * 60;
          triggerNotification("BREAK TIME!", "Time for your 2-minute break.");
        } else {
          mode = "Focus";
          timeLeft = FOCUS_TIME * 60;
          triggerNotification("FOCUS TIME!", "Get back to work for 10 minutes.");
        }
      }
      chrome.storage.local.set({ timeLeft, mode });
    });
  }
});

function triggerNotification(title, message) {
  chrome.notifications.create({
    type: "basic",
    iconUrl: "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='red'><path d='M12 22c1.1 0 2-.9 2-2h-4c0 1.1.89 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z'/></svg>",
    title: title,
    message: message,
    priority: 2,
    requireInteraction: true // Keeps the notification on screen until you click it
  });
}