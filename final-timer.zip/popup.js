const statusDiv = document.getElementById("status");
const timerDiv = document.getElementById("timer");
const actionBtn = document.getElementById("actionBtn");

// FUNCTION TO CREATE A LOUD SYNTHETIC BEEP
function playLoudBeep() {
    const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    const oscillator = audioCtx.createOscillator();
    const gainNode = audioCtx.createGain();

    oscillator.type = 'square'; // 'square' is much louder and harsher than 'sine'
    oscillator.frequency.setValueAtTime(880, audioCtx.currentTime); // High pitch (A5)
    
    gainNode.gain.setValueAtTime(0.5, audioCtx.currentTime); // Volume (0 to 1)
    
    oscillator.connect(gainNode);
    gainNode.connect(audioCtx.destination);

    oscillator.start();
    // Beep for 1 second
    setTimeout(() => oscillator.stop(), 1000);
}

// Listen for the "play_sound" message from the background script
chrome.runtime.onMessage.addListener((message) => {
    if (message.action === "play_sound") {
        playLoudBeep();
    }
});

function updateUI() {
  chrome.storage.local.get(["isRunning", "mode", "timeLeft"], (data) => {
    if (data.isRunning) {
      statusDiv.textContent = data.mode + " Mode";
      actionBtn.textContent = "Stop";
      actionBtn.className = "stop";
    } else {
      statusDiv.textContent = "Idle";
      actionBtn.textContent = "Start";
      actionBtn.className = "";
    }

    const minutes = Math.floor(data.timeLeft / 60);
    const seconds = data.timeLeft % 60;
    timerDiv.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
  });
}

setInterval(updateUI, 1000);
updateUI();

actionBtn.addEventListener("click", () => {
  chrome.storage.local.get("isRunning", (data) => {
    if (data.isRunning) {
      chrome.runtime.sendMessage({ action: "stop" });
    } else {
      chrome.runtime.sendMessage({ action: "start" });
    }
    setTimeout(updateUI, 50);
  });
});