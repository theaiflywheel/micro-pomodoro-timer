const quotes = [
  "Stay focused, stay humble.",
  "Make it happen.",
  "Quality over quantity.",
  "Focus is a superpower.",
  "Progress, not perfection."
];

function updateUI() {
  chrome.storage.local.get(["timeLeft", "mode", "isRunning", "sessions"], (data) => {
    const total = data.mode === "Focus" ? 600 : 120;
    const percent = (data.timeLeft / total) * 100;
    
    document.getElementById('wave').style.height = `${percent}%`;
    document.getElementById('wave').style.background = data.mode === "Focus" 
      ? "linear-gradient(180deg, #38bdf8 0%, #0ea5e9 100%)" 
      : "linear-gradient(180deg, #4ade80 0%, #16a34a 100%)";

    document.getElementById('mode').textContent = data.mode === "Focus" ? "Deep Focus" : "Short Break";
    document.getElementById('mode').style.color = data.mode === "Focus" ? "#38bdf8" : "#4ade80";
    document.getElementById('streakCount').textContent = data.sessions || 0;

    const mins = Math.floor(data.timeLeft / 60);
    const secs = data.timeLeft % 60;
    document.getElementById('time').textContent = `${mins}:${secs.toString().padStart(2, '0')}`;
  });
}

// Change quote every time they open the popup
document.getElementById('quote').textContent = `"${quotes[Math.floor(Math.random() * quotes.length)]}"`;

document.getElementById('startBtn').onclick = () => chrome.runtime.sendMessage({ action: "start" });
document.getElementById('stopBtn').onclick = () => chrome.runtime.sendMessage({ action: "stop" });

setInterval(updateUI, 1000);
updateUI();