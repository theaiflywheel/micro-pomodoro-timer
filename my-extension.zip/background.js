const FOCUS = 10 * 60;
const BREAK = 2 * 60;

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({ isRunning: false, mode: 'Focus', timeLeft: FOCUS, sessions: 0 });
});

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.action === "start") {
    chrome.storage.local.set({ isRunning: true });
    chrome.alarms.create("focusTimer", { periodInMinutes: 1/60 });
  }
  if (msg.action === "stop") {
    chrome.alarms.clearAll();
    chrome.storage.local.set({ isRunning: false, timeLeft: FOCUS, mode: "Focus" });
  }
});

chrome.alarms.onAlarm.addListener(async () => {
  let data = await chrome.storage.local.get(["timeLeft", "mode", "sessions"]);
  let timeLeft = data.timeLeft - 1;
  let mode = data.mode;
  let sessions = data.sessions || 0;

  if (timeLeft <= 0) {
    await triggerSound();
    if (mode === "Focus") {
      mode = "Break";
      timeLeft = BREAK;
      sessions++; // Level Up the streak!
    } else {
      mode = "Focus";
      timeLeft = FOCUS;
    }
  }
  chrome.storage.local.set({ timeLeft, mode, sessions });
});

async function triggerSound() {
  if (!(await chrome.offscreen.hasDocument?.())) {
    await chrome.offscreen.createDocument({
      url: 'offscreen.html', reasons: ['AUDIO_PLAYBACK'], justification: 'Alarm'
    });
  }
  chrome.runtime.sendMessage({ action: "play_beep" });
}