const statusDiv = document.getElementById("status");
const timerDiv = document.getElementById("timer");
const actionBtn = document.getElementById("actionBtn");

function updateUI() {
  chrome.storage.local.get(["isRunning", "mode", "timeLeft"], (data) => {
    if (data.isRunning) {
      statusDiv.textContent = data.mode + " Mode";
      actionBtn.textContent = "Stop";
      actionBtn.className = "stop";
    } else {
      statusDiv.textContent = "Idle";
      actionBtn.textContent = "Start";
      actionBtn.className = "";
    }

    const minutes = Math.floor(data.timeLeft / 60);
    const seconds = data.timeLeft % 60;
    timerDiv.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
  });
}

setInterval(updateUI, 1000);
updateUI();

actionBtn.addEventListener("click", () => {
  chrome.storage.local.get("isRunning", (data) => {
    if (data.isRunning) {
      chrome.runtime.sendMessage({ action: "stop" });
    } else {
      chrome.runtime.sendMessage({ action: "start" });
    }
    setTimeout(updateUI, 50);
  });
});