const FOCUS_TIME = 10; 
const BREAK_TIME = 2;   

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({ 
    isRunning: false, 
    mode: 'Focus', 
    timeLeft: FOCUS_TIME * 60 
  });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "start") {
    startTimer();
  } else if (message.action === "stop") {
    stopTimer();
  }
});

function startTimer() {
  chrome.storage.local.set({ isRunning: true });
  chrome.alarms.create("pomodoroAlarm", { periodInMinutes: 1 / 60 });
}

function stopTimer() {
  chrome.alarms.clear("pomodoroAlarm");
  chrome.storage.local.set({ 
    isRunning: false, 
    mode: 'Focus', 
    timeLeft: FOCUS_TIME * 60 
  });
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "pomodoroAlarm") {
    chrome.storage.local.get(["timeLeft", "mode"], (data) => {
      let timeLeft = data.timeLeft - 1;
      let mode = data.mode;

      if (timeLeft <= 0) {
        if (mode === "Focus") {
          mode = "Break";
          timeLeft = BREAK_TIME * 60;
          triggerNotification("Break Time!", "Take a 2-minute breather.");
        } else {
          mode = "Focus";
          timeLeft = FOCUS_TIME * 60;
          triggerNotification("Back to Work!", "Time to focus for 10 minutes.");
        }
      }
      chrome.storage.local.set({ timeLeft, mode });
    });
  }
});

function triggerNotification(title, message) {
  chrome.notifications.create({
    type: "basic",
    iconUrl: "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='48' height='48' viewBox='0 0 24 24' fill='%23FF0000'><path d='M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z'/></svg>",
    title: title,
    message: message,
    priority: 2
  });
}